/**
 * Project 1 - Interactive Image
 * Name: Andrea Romero; October 6th;
 Plane in cloudy sky
 Plane flies in sky full of cloudsmouse is pressed down on.; 
 
 */
var x= 275 //location on x axis
var y= 250// location on y axis
var d= 100// diameter of plane
var r= 0// rotation
// Global Variables go here


function setup(){
  // this function will run once
  createCanvas(550, 500); // create a 600x400 pixel drawing canvas
  
}

function draw(){
  // this function runs again and again (60x per second)
  background(205,226,250); //light blue sky
  myPlane (x, y, d, r);

function myPlane (tempX, tempY, tempD, tempR){
  let r = tempR;
  let d = tempD
  let gray= color (210) //plane color
  
  push(); //layer 2
  
  
  translate(x,y)//plane in center
  
  //plane body
  noStroke()
  fill(gray)
  ellipse(0,0, 350,60)

  //plane windows
  fill(0)
  for(i=-110;i<140; i+=10){
  ellipse(i,0,5,5)  
  }
  //plane wings
  fill(gray)
  quad(-50,20, 30,20, -80,80, -100,80)
  quad(30,-20, -30,-20, 30,-70, 50,-70 )
  pop();
  
  //clouds
  var c= 50
  var t=60
  // for size of clouds
  
  
  noStroke();
  fill (255);
  ellipse( 50, c, c, t);
  ellipse( 80, c, c, t);
  ellipse( 110, c, c,t);

  noStroke();
  fill (255);
  ellipse( 190, c, c, t);
  ellipse( 220, c, c,t);
  ellipse( 250, c, c, t);

  noStroke();
  fill (255);
  ellipse( 330, c, c, 60);
  ellipse( 360, c, c, 60);
  ellipse( 380, c, c, 60);


  
  pop();
  

/* 
  Use the following if()...else() structure to incorporate mouse click control of your animation
*/
  
  if(mouseIsPressed){
   x++;
    //plane flies away
  } else {
     fill(0);
    
    
  }

}


}